function showDiv(select){
    
    if(select.value==0) {
      document.getElementById('Diplomet').style.display = "none";
      document.getElementById('master').style.display = "none";
      document.getElementById('PhD').style.display = "none";
    }
      else if(select.value==1){
        document.getElementById('Diplomet').style.display = "block";
    }    
      else if(select.value==2){
        document.getElementById('master').style.display = "block";
    } 
      else if(select.value==3){
        document.getElementById('PhD').style.display = "block";
    } 

 } 