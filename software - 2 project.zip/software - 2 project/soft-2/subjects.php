<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Subjects</title>
        <style>
            input[type="text"] {
                width:100%;
                padding:10px;
                margin:10px;
            }
            h2 {
                padding: 20px;
            }
            div {
                width:50%;
                float:left;
            }
            div img {
                margin-left: 80px;
                margin-top: 60px;
            }
            input[type="submit"] {
                border:2px solid black;
                padding: 30px;
                border-radius: 20px;
                margin:20px;
                background-color: tomato;
            }
        </style>
        <link rel="stylesheet" href="css/css.css">
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="sign up.php">Sing Up</a></li>
                <li><a href="admin.php">Admin</a></li>
                <li><a href="student.php">Student</a></li>
            </ul>
            <div class="signIn"> 
                <form class="signForm">
                    <input type="email" name="inEmail" placeholder="Your email... " />
                    <input type="password" name="inPass" placeholder="Your pass... " />
                    <input type="submit"/>
                </form>
            </div>
        </nav>

        <header>
            <h1>Subjects regestratin</h1>
        </header>
        <main>
            <h2>Write the 6 Subjects:<h2>
            <article style="overflow:hidden">
            <div>
                <form method="POST" action="subj.php">
                    <label>INPUT Your Name: </label>
                    <input type="text" name="name" /> <br />
                    <label>Subject 1: </label>
                    <input type="text" name="sub1" /> <br />
                    <label>Subject 2: </label>
                    <input type="text" name="sub2" /> <br />
                    <label>Subject 3: </label>
                    <input type="text" name="sub3" /> <br />
                    <label>Subject 4: </label>
                    <input type="text" name="sub4" /> <br />
                    <label>Subject 5: </label>
                    <input type="text" name="sub5" /> <br />
                    <label>Subject 6: </label>
                    <input type="text" name="sub6" /> <br />
                    <input type="submit" />
                </form>
            </div>
            <div>
                <img src="images/unnamed.jpg" />
            </div>
        </article>
            <div ></div>
        <footer id="footer">
            <h4>beast wishies</h4>
            <p>&copy; 2020 - 2021  All Rights Reserved </p>
        </footer>
    </body>
</html>