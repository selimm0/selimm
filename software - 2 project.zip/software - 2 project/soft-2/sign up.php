<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Sign Up</title>
        <link rel="stylesheet" href="css/css.css">
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="subjects.php">Subjects</a></li>
                <li><a href="admin.php">Admin</a></li>
                <li><a href="student.php">Student</a></li>
            </ul>
            <div class="signIn"> 
                <form class="signForm">
                    <input type="email" name="inEmail" placeholder="Your email... " />
                    <input type="password" name="inPass" placeholder="Your pass... " />
                    <input type="submit"/>
                </form>
            </div>
        </nav>

        <header>
            <h1>Sign Up Page</h1>
        </header>

        <main id="singUp">
            <div class="container">
                <form id="form-group-1" action="conect.php" method="POST">
                    <h2>Registration form for postgraduate studies</h2>
                    <div>
                        <label for="fname">First Name: </label>
                        <input type="text" id="fname" name="firstname" placeholder="Your name... " required>

                        <label for="lname">Last Name: </label>
                        <input type="text" id="lname" name="lastname" placeholder="Your last name... " required>

                        <label for="birthDate">Birth Date: </label>
                        <input type="date" id="birthDate" name="birthDate" required>
                        
                        
                        <label for="birthPlace">Birth Place: </label>
                        <input type="text" id="birthPlace" name="birthPlace" placeholder="Your Birth place.." required>

                        <label for="Nationality">Nationality: </label>
                        <input type="text" id="Nationality" name="Nationality" placeholder="Your Nationality.." required>

                        <label for="NationalID">National ID: </label>
                        <input type="text" id="NationalID" name="NationalID" placeholder="Your National ID" maxlength="14" required>
                        
                        <label for="The position on military recruitment">The Position On Military Recruitment: </label>
                        <input type="text" id="The position on military recruitment" name="positionOnMilitary" placeholder="Your position on military recruitment.." required>
                        
                        <label for="address">Address: </label>
                        <input type="text" id="address" name="address" placeholder="Your Address.." required>

                        <label for="Email">Email: </label>
                        <input type="email" id="Email" name="Email" placeholder="Your email.." required>

                        <label for="password">Password</label>
                        <input type="password" id="password" placeholder="Your password.." name="password" required>
                    
                        <label for="certifcate">postgraduate studies</label>
                        <select id="certifcate" name="certifcate" onchange="showDiv(this)">
                            <option selected value="0">Select postgraduate studies:</option>
                            <option value="1" >Diplomet</option>
                            <option value="2">master</option>
                            <option value="3">PhD</option>
                        </select>

                        <div id="Diplomet" style="display: none;">
                            <label for="job">Current job:</label>
                            <input type="text" name = "job">

                            <label for="degree">Bchelors degree:</label>
                            <input type="text" name = "degree" >

                            <label for="app">Apprecation:</label>
                            <input type="text" name="Apprecation" >

                            <label for="college">College:</label>
                            <input type="text" name="college" >

                            <label for="uinv">University:</label>
                            <input type="text" name="University" >

                            <label for="depart">Department:</label>
                            <input type="text" name="Department" > 

                            <label for="student">Student signature:</label>
                            <input type="text" name="StudentSignature" >
                        </div>  
                        
                        <div id="master"  style="display: none;">
                            <label for="job">Current job:</label>
                            <input type="text" name = "job">

                            <label for="degree">Bchelors degree:</label>
                            <input type="text" name = "degree" >

                            <label for="app">Apprecation:</label>
                            <input type="text" name="Apprecation" >

                            <label for="college">College:</label>
                            <input type="text" name="college" >

                            <label for="uinv">University:</label>
                            <input type="text" name="University" >

                            <label for="depart">Department:</label>
                            <input type="text" name="Department" > 

                            <label for="StudentSignature">Student Signature:</label>
                            <input type="text" name="StudentSignature" >

                            <label for="postgraduate">postgraduateDiploma:</label>
                            <input type="text" name="postgraduateDiploma" >
                        </div>

                        <div id="PhD"  style="display: none;">
                            <label for="job">Current job:</label>
                            <input type="text" >

                            <label for="degree">Bchelors degree:</label>
                            <input type="text" >

                            <label for="app">Apprecation:</label>
                            <input type="text">

                            <label for="college">College:</label>
                            <input type="text" >

                            <label for="uinv">University:</label>
                            <input type="text" >

                            <label for="depart">Department:</label>
                            <input type="text" >

                            <label for="postgraduate">postgraduate diploma:</label>
                            <input type="text" name="postgraduateDiploma" >          
                        </div>

                    </div>
                    <button class="button" style="vertical-align:middle"><span>Submit</span></button>
                </form>
            </div>
        </main>

        <footer id="footer">
            <h4>beast wishies</h4>
            <p>&copy; 2020 - 2021  All Rights Reserved </p>
        </footer>
        <script src="js/js.js"></script>
    </body>
</html>