<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Student</title>
        <style>
            input[type="text"] {
                width:100%;
                padding:10px;
                margin:10px;
            }
            table {
                background-color:#fff;
                border:1px solid #000;
                border-collapse:collapse; 
                text-align: center;
                width:100%;
            }
            td {
                text-align:center;
                border:1px solid #000;
                padding:20px 0;
            }
            input[type="submit"] {
                border:2px solid black;
                padding: 30px;
                border-radius: 20px;
                margin:20px;
                background-color: tomato;
            }
        </style>
        <link rel="stylesheet" href="css/css.css">
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="sign up.php">Sing Up</a></li>
                <li><a href="subjects.php">Subjects</a></li>
                <li><a href="admin.php">Admin</a></li>
            </ul>
            <div class="signIn"> 
                <form class="signForm">
                    <input type="email" name="inEmail" placeholder="Your email... " />
                    <input type="password" name="inPass" placeholder="Your pass... " />
                    <input type="submit"/>
                </form>
            </div>
        </nav>

        <header>
            <h1>Student Subjects</h1>
        </header>

        <main>
            <div>
                <table>
                    <?php
                        $servername='localhost';
                        $username='root';
                        $password='';
                        $dbname = "fci_phd";
                        $conn = new mysqli($servername, $username, $password, $dbname);
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }
                        $tabel = "subjects";
                        $sql = "SELECT * FROM $tabel";
                        $result = $conn->query($sql);
                        if ($result) {
                            while($row = $result->fetch_assoc()) {
                                echo "<tr> <td>".$row["student_name"].                 "</td> <td>".$row["Sub1"].            "</td> <td>".$row["sub1_score"].
                                    "</td> <td>".$row["Sub2"].          "</td> <td>".$row["sub2_score"].          "</td> <td>".$row["Sub3"]. 
                                    "</td> <td>".$row["sub3_score"]. "</td> <td>".$row["Sub4"].              "</td> <td>".$row["sub4_score"].
                                    "</td> <td>".$row["Sub5"].             "</td> <td>".$row["sub5_score"]. "</td> <td>".$row["Sub6"]. 
                                    "</td> <td>".$row["sub6_score"]."</td> </tr>";            
                            }
                        } else { echo "0 results"; }
                        $conn->close();
                    ?>
                </table>
            <div>
            <div>
            
                <form method="POST"  action="deg.php">
                    <label > NAME:</label>
                    <input type="text" name="name1"/>
                    <label for="s1">Degree Subject 1: </label>
                    <input type="text" id="s1" name="s1"/>
                    <label for="s2">Degree Subject 2: </label>
                    <input type="text" id="s2" name="s2"/>
                    <label for="s3">Degree Subject 3: </label>
                    <input type="text" id="s3" name="s3"/>
                    <label for="s4">Degree Subject 4: </label>
                    <input type="text" id="s4" name="s4"/>
                    <label for="s5">Degree Subject 5: </label>
                    <input type="text" id="s5" name="s5"/>
                    <label for="s6">Degree Subject 6: </label>
                    <input type="text" id="s6" name="s6"/>
                    <input type="submit" />
                </form>
            </div>
        </main>

        <footer id="footer">
            <h4>beast wishies</h4>
            <p>&copy; 2020 - 2021  All Rights Reserved </p>
        </footer>

    </body>
</html>