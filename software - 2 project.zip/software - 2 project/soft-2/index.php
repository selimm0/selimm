<?php
    $servername='localhost';
    $username='root';
    $password='';
    $dbname = "fci_phd";
    $conn=mysqli_connect($servername,$username,$password,$dbname);
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Graduate Studies</title>
        <link rel="stylesheet" href="css/css.css">
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="sign up.php">Sing Up</a></li>
                <li><a href="subjects.php">Subjects</a></li>
                <li><a href="admin.php">Admin</a></li>
                <li><a href="student.php">Student</a></li>
            </ul>
            <div class="signIn"> 
                <form class="signForm" name="f1" action = "authentication.php" onsubmit = "return validation()" method = "POST">
                    <input id ="user" name  = "em" type="email" placeholder="Your email... " />
                    <input id ="pass" name  = "pass" type="password" placeholder="Your pass... " />
                    <input type="submit"/>
                </form>
            </div>
        </nav>
    
        <header>
            <h1>Welcome to Graduate Studies F-C-I</h1>
        </header>
        <article id="about">
            <section>
                <div>
                    <h2>Explore our list of all graduate schools. Find your desired masters degree, doctoral degree, or online graduate program. </h2>
                    <p>&nbsp; FCI is a private graduate school in Cambridge, Massachusetts in the Boston Area. It has a big graduate student body with an enrollment of 6,972 graduate students. The 38 graduate programs at Massachusetts Institute of Technology are all on-campus only and none are offered online. The most popular graduate school programs at Massachusetts Institute of Technology are Business, Computer Science, and Mechanical Engineering. 2% of its graduate students are part-time graduate students.</p>
                    <p>&nbsp; FCI is a private graduate school in Stanford, California in the San Francisco Bay Area. It has a large graduate student body with an enrollment of 10,294 graduate students. Of the 80 graduate programs offered at Stanford University, 11 are offered online or through graduate distance education programs. The most popular graduate school programs at Stanford University are Business, Computer Science, and Electrical Engineering. 10% of its graduate students are part-time graduate students.</p>
                    <p>&nbsp; FCI is a private graduate school in Cambridge, Massachusetts in the Boston Area. It has a big graduate student body with an enrollment of 6,972 graduate students. The 38 graduate programs at Massachusetts Institute of Technology are all on-campus only and none are offered online. The most popular graduate school programs at Massachusetts Institute of Technology are Business, Computer Science, and Mechanical Engineering. 2% of its graduate students are part-time graduate students.</p>
                    <p>&nbsp; FCI is a private graduate school in Stanford, California in the San Francisco Bay Area. It has a large graduate student body with an enrollment of 10,294 graduate students. Of the 80 graduate programs offered at Stanford University, 11 are offered online or through graduate distance education programs. The most popular graduate school programs at Stanford University are Business, Computer Science, and Electrical Engineering. 10% of its graduate students are part-time graduate students.</p>
                    <p>&nbsp; FCI is a private graduate school in Cambridge, Massachusetts in the Boston Area. It has a big graduate student body with an enrollment of 6,972 graduate students. The 38 graduate programs at Massachusetts Institute of Technology are all on-campus only and none are offered online. The most popular graduate school programs at Massachusetts Institute of Technology are Business, Computer Science, and Mechanical Engineering. 2% of its graduate students are part-time graduate students.</p> 
                </div>
            </section>
            <aside>
                <div>
                    <img src="images/unnamed.jpg">
                    <p>&nbsp; Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dicta, inventore. Exercitationem quisquam, fugiat quidem totam iste autem commodi quas? Error soluta itaque nemo vel quas, iusto ab quos velit possimus!</p>
                </div>
                <div>
                    <img src="images/unnamed.jpg">
                    <p>&nbsp; Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dicta, inventore. Exercitationem quisquam, fugiat quidem totam iste autem commodi quas? Error soluta itaque nemo vel quas, iusto ab quos velit possimus!</p>    
                </div>
            </aside>
            
            <div style="clear: both;"></div>
        </article>
        <footer id="footer">
            <h4>beast wishies</h4>
            <p>&copy; 2020 - 2021  All Rights Reserved </p>
        </footer>

        <script src="js/js.js" ></script>
        <script>  
            function validation()  
            {  
                var id=document.f1.user.value;  
                var ps=document.f1.pass.value;  
                if(id.length=="" && ps.length=="") {  
                    alert("User Name and Password fields are empty");  
                    return false;  
                }  
                else  
                {  
                    if(id.length=="") {  
                        alert("User Name is empty");  
                        return false;  
                    }   
                    if (ps.length=="") {  
                    alert("Password field is empty");  
                    return false;  
                    }  
                }                             
            }  
        </script>  
    </body>
</html>