<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin</title>
        <style>
            table {
                background-color:#fff;
                border:1px solid #000;
                border-collapse:collapse; 
                text-align: center;
                margin:0;
                position:relative;
                left: -68px
            }
            td {
                text-align:center;
                border:1px solid #000;
            }
            input[type="submit"] {
                border:2px solid black;
                padding: 30px;
                border-radius: 20px;
                margin:20px;
                background-color: tomato;
            }
        </style>
        <link rel="stylesheet" href="css/css.css">
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="sign up.php">Sing Up</a></li>
                <li><a href="subjects.php">Subjects</a></li>
                <li><a href="student.php">Student</a></li>
            </ul>
            <div class="signIn"> 
                <form class="signForm">
                    <input type="email" name="inEmail" placeholder="Your email... " />
                    <input type="password" name="inPass" placeholder="Your pass... " />
                    <input type="submit"/>
                </form>
            </div>
        </nav>
        <header>
            <h1>The Admin Page</h1>
        </header>
        <main>
        <form action="accepted.php" method="POST">
            <table>
                <?php
                    $servername='localhost';
                    $username='root';
                    $password='';
                    $dbname = "fci_phd";
                    $conn = new mysqli($servername, $username, $password, $dbname);
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }
                    $tabel = "students";
                    $sql = "SELECT * FROM $tabel";
                    $result = $conn->query($sql);
                    if ($result) {
                        while($row = $result->fetch_assoc()) {
                            echo"<tr> <td>".
                                "</td> <td>".$row["first_name"].           "</td> <td>".$row["last_name"].            "</td> <td>".$row["birth_date"].
                                "</td> <td>".$row["birth_place"].          "</td> <td>".$row["nationality"].          "</td> <td>".$row["national _id"]. 
                                "</td> <td>".$row["position_on_military"]. "</td> <td>".$row["address"].              "</td> <td>".$row["email"].
                                "</td> <td>".$row["password"].             "</td> <td>".$row["postgraduate_studies"]. "</td> <td>".$row["current_job"]. 
                                "</td> <td>".$row["bchelors_degree"].      "</td> <td>".$row["apprecation"].          "</td> <td>".$row["college"]. 
                                "</td> <td>".$row["university"].            "</td> <td>".$row["department"].           "</td> <td>".$row["student_signature"].
                                "</td> <td>".$row["postgraduate_diploma"]. "</td> <td>".
                                "<input type='checkbox' name='accept' value='1'>".       "</td> </tr>";            
                        }
                    } else { echo "0 results"; }
                    $conn->close();
                ?>
            </table>
            <input type="submit" />
        </form>
        </main>
        <footer id="footer">
            <h4>beast wishies</h4>
            <p>&copy; 2020 - 2021  All Rights Reserved </p>
        </footer>
    </body>
</html>