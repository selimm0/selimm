<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Connect</title>
        <link rel="stylesheet" href="css/css.css">
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="sign up.php">Sing Up</a></li>
                <li><a href="subjects.php">Subjects</a></li>
                <li><a href="student.php">Student</a></li>
                <li><a href="admin.php">Admin</a></li>
            </ul>
            <div class="signIn"> 
                <form class="signForm">
                    <input type="email" name="inEmail" placeholder="Your email... " />
                    <input type="password" name="inPass" placeholder="Your pass... " />
                    <input type="submit"/>
                </form>
            </div>
        </nav>
        <header>
            <h1>connect Page</h1>
        </header>
        <main>
            <?php     
                $host = "localhost";  
                $user = "root";  
                $password = '';  
                $db_name = "log";  
                
                $con = mysqli_connect($host, $user, $password, $db_name);  
                if(mysqli_connect_errno()) {  
                    die("Failed to connect with MySQL: ". mysqli_connect_error());  
                }  
            
                $em = $_POST['em'];  
                $password = $_POST['pass'];  
                
                    //to prevent from mysqli injection  
                $em = stripcslashes($em);  
                $password = stripcslashes($password);  
                $em = mysqli_real_escape_string($con, $em);  
                $password = mysqli_real_escape_string($con, $password);  
                
                $sql = "select *from login where pass = '$password'";  
                $result = mysqli_query($con, $sql);  
                $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
                $count = mysqli_num_rows($result);  
                    
                if($count == 1){  
                    echo "<h1><center> Login successful </center></h1>";  
                }  
                else{  
                        echo "<h1> Login failed. Invalid username or password.</h1>";  
                }     
            ?>  
    </main>
        <footer id="footer">
            <h4>beast wishies</h4>
            <p>&copy; 2020 - 2021  All Rights Reserved </p>
        </footer>
    </body>
</html>

