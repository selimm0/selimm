
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Connect</title>
        <link rel="stylesheet" href="css/css.css">
    </head>
    <body>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="sign up.php">Sing Up</a></li>
                <li><a href="subjects.php">Subjects</a></li>
                <li><a href="student.php">Student</a></li>
                <li><a href="admin.php">Admin</a></li>
            </ul>
            <div class="signIn"> 
                <form class="signForm">
                    <input type="email" name="inEmail" placeholder="Your email... " />
                    <input type="password" name="inPass" placeholder="Your pass... " />
                    <input type="submit"/>
                </form>
            </div>
        </nav>
        <header>
            <h1>connect Page</h1>
        </header>
        <main>
            
<?php


//php conection
$servername='localhost';
$username='root';
$password='';
$dbname = "fci_phd";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$fin = $_POST['firstname'];
$lan = $_POST['lastname'];
$bid = $_POST['birthDate'];
$bip = $_POST['birthPlace'];
$nat = $_POST['Nationality'];
$nid = $_POST['NationalID'];
$pom = $_POST['positionOnMilitary'];
$adr = $_POST['address'];
$ema = $_POST['Email'];
$pas = $_POST['password'];

$cer = $_POST['certifcate'];
$job = $_POST['job'];
$deg = $_POST['degree'];
$app = $_POST['Apprecation'];
$col = $_POST['college'];
$uni = $_POST['University'];
$dep = $_POST['Department'];
$sts = $_POST['StudentSignature'];
$pod = $_POST['postgraduateDiploma'];
$acc = false;

$tabel = 'students';
$sql = "INSERT INTO $tabel VALUES ('$fin', '$lan', '$bid', '$bip', '$nat', '$nid', 
                                    '$pom', '$adr', '$ema', '$pas', '$cer', '$job',
                                    '$deg', '$app', '$col', '$uni', '$dep', '$sts',
                                    '$pod', '$acc')";
  
if ($conn->query($sql) === TRUE) {
    echo "<h2>New record created successfully</h2>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
  
$conn->close();
?>
        </main>
        <footer id="footer">
            <h4>beast wishies</h4>
            <p>&copy; 2020 - 2021  All Rights Reserved </p>
        </footer>
    </body>
</html>



